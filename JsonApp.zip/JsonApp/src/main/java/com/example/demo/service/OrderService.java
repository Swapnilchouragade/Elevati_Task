package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.OrderModel;
import com.example.demo.repository.OrderCategoryRepository;


@Service
public class OrderService implements IOrderService {
	@Autowired
	private OrderCategoryRepository orderRepository;

	@Override
	public List<OrderModel> getAllOrders() {
		List<OrderModel> list = new ArrayList<>();
		orderRepository.findAll().forEach(e -> list.add(e));
		return list;
	}
}
