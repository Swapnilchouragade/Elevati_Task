package com.example.demo.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "order_tax")
public class TaxLineModel {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	@Column(name = "tTitle")
	private String title;
	@Column(name = "tPrice")
	private BigDecimal price;
	@Column(name = "tRate")
	private BigDecimal rate;
	@ManyToOne
	@JoinColumn(name = "order_tax_col")
	private ProductLineModel productLineModel;

	public ProductLineModel getProductLineModel() {
		return productLineModel;
	}

	public void setProductLineModel(ProductLineModel productLineModel) {
		this.productLineModel = productLineModel;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

}
