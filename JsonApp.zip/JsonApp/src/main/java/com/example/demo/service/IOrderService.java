package com.example.demo.service;

import java.util.List;

import com.example.demo.model.OrderModel;

public interface IOrderService {
	public List<OrderModel> getAllOrders() ;
}
