package com.example.demo.model;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "order_line")
public class ProductLineModel {
	@Id
	private long id;
	private String title;
	private long quantity;
	private BigDecimal price;
	private String sku;
	private String vendor;
	private long product_id;
	private boolean requires_shipping;
	private boolean taxable;
	private boolean gift_card;
	private String name;
	private boolean product_exists;
	private long grams;
	private BigDecimal total_discount;
	@ManyToOne
	@JoinColumn(name = "order_Model_id")
	private OrderModel orderModel;
	@OneToMany(mappedBy = "productLineModel", cascade = CascadeType.ALL)
	private List<TaxLineModel> tax_lines;

	public List<TaxLineModel> getTax_lines() {
		return tax_lines;
	}

	public void setTax_lines(List<TaxLineModel> tax_lines) {
		this.tax_lines = tax_lines;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public long getProduct_id() {
		return product_id;
	}

	public void setProduct_id(long product_id) {
		this.product_id = product_id;
	}

	public boolean isRequires_shipping() {
		return requires_shipping;
	}

	public void setRequires_shipping(boolean requires_shipping) {
		this.requires_shipping = requires_shipping;
	}

	public boolean isTaxable() {
		return taxable;
	}

	public void setTaxable(boolean taxable) {
		this.taxable = taxable;
	}

	public boolean isGift_card() {
		return gift_card;
	}

	public void setGift_card(boolean gift_card) {
		this.gift_card = gift_card;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isProduct_exists() {
		return product_exists;
	}

	public void setProduct_exists(boolean product_exists) {
		this.product_exists = product_exists;
	}

	public long getGrams() {
		return grams;
	}

	public void setGrams(long grams) {
		this.grams = grams;
	}

	public BigDecimal getTotal_discount() {
		return total_discount;
	}

	public void setTotal_discount(BigDecimal total_discount) {
		this.total_discount = total_discount;
	}

	public OrderModel getOrderModel() {
		return orderModel;
	}

	public void setOrderModel(OrderModel orderModel) {
		this.orderModel = orderModel;
	}

}
