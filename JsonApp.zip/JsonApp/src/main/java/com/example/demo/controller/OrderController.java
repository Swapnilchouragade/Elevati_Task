package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.OrderModel;
import com.example.demo.service.IOrderService;

@Controller
public class OrderController {
@Autowired
private IOrderService orderService;
@RequestMapping("/")
public String welcome() {
	System.out.println("UserController Welcome========");
	return "test";
}
@GetMapping(value = "/orderDetails")
	public String getOrderDetails(Model  model) {
		List<OrderModel> oList=orderService.getAllOrders();		
		model.addAttribute("oList", oList);
		return "orderList";
	}
}
