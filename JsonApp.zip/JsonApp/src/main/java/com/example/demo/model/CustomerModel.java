package com.example.demo.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
@Embeddable
public class CustomerModel {
	@Column(name="cust_id")
	private long id;
	@Column(name="cust_email")
	private String email;
	@Column(name="cust_market")
	private boolean accepts_marketing;
	@Column(name="custfname")
	private String first_name;
	@Column(name="custlname")
	private String last_name;
	private long orders_count;
	@Column(name="custstate")
	private String state;
	private BigDecimal total_spent;
	private boolean tax_exempt;
	@Column(name="custphone")
	private String phone;
	@Column(name="custcurrency")
	
	private String currency;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isAccepts_marketing() {
		return accepts_marketing;
	}
	public void setAccepts_marketing(boolean accepts_marketing) {
		this.accepts_marketing = accepts_marketing;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public long getOrders_count() {
		return orders_count;
	}
	public void setOrders_count(long orders_count) {
		this.orders_count = orders_count;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public BigDecimal getTotal_spent() {
		return total_spent;
	}
	public void setTotal_spent(BigDecimal total_spent) {
		this.total_spent = total_spent;
	}
	public boolean isTax_exempt() {
		return tax_exempt;
	}
	public void setTax_exempt(boolean tax_exempt) {
		this.tax_exempt = tax_exempt;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
}
