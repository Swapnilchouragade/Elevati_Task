package com.example.demo;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.transaction.Transactional;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.domain.BillAddress;
import com.example.demo.domain.Customer;
import com.example.demo.domain.LineItem;
import com.example.demo.domain.Order;
import com.example.demo.domain.ShipAddress;
import com.example.demo.domain.TaxItem;
import com.example.demo.model.BillAddressModel;
import com.example.demo.model.CustomerModel;
import com.example.demo.model.OrderModel;
import com.example.demo.model.ProductLineModel;
import com.example.demo.model.ShipAddressModel;
import com.example.demo.model.TaxLineModel;
import com.example.demo.repository.OrderCategoryRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootApplication
public class JsonAppApplication implements CommandLineRunner {

	@Autowired
	private OrderCategoryRepository orderCategoryRepository;

	public static void main(String[] args) {
		SpringApplication.run(JsonAppApplication.class, args);

	}

	@Override
	@Transactional
	public void run(String... strings) throws Exception {
		try {
			URL url = new URL("https://elevatitech.com/api/test/shopify/orders");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			int responsecode = conn.getResponseCode();
			String inline = "";
			if (responsecode != 200)
				throw new RuntimeException("HttpResponseCode: " + responsecode);
			else {
				Scanner sc = new Scanner(url.openStream());
				while (sc.hasNext()) {
					inline += sc.nextLine();
				}

				JSONParser parse = new JSONParser();
				JSONObject jobj = (JSONObject) parse.parse(inline);
				JSONArray jsonarr_1 = (JSONArray) jobj.get("orders");

				ObjectMapper mapper = new ObjectMapper();

				List<Order> orders = new ArrayList<Order>();
				for (int i = 0; i < jsonarr_1.size(); i++) {
					JSONObject jsonobj_1 = (JSONObject) jsonarr_1.get(i);

					Order order = mapper.readValue(jsonobj_1.toJSONString().getBytes(), Order.class);

					orders.add(order);

				}
				System.out.println("show order-->" + Arrays.asList(orders));

				List<OrderModel> ordersModel = new ArrayList<OrderModel>();

				for (Order order : orders) {
					OrderModel orderModel = new OrderModel();

					Customer customer = order.getCustomer();
					CustomerModel customerModel = new CustomerModel();
					if (null != customer) {
						customerModel.setAccepts_marketing(customer.isAccepts_marketing());
						customerModel.setCurrency(customer.getCurrency());
						customerModel.setEmail(customer.getEmail());
						customerModel.setFirst_name(customer.getFirst_name());
						customerModel.setId(customer.getId());
						customerModel.setLast_name(customer.getLast_name());
						customerModel.setOrders_count(customer.getOrders_count());
						customerModel.setPhone(customer.getPhone());
						customerModel.setState(customer.getState());
						customerModel.setTax_exempt(customer.isTax_exempt());
						customerModel.setTotal_spent(customer.getTotal_spent());
					}
					orderModel.setCustomer(customerModel);

					ShipAddress shipAddress = order.getShipping_address();
					ShipAddressModel shipAddrModel = new ShipAddressModel();
					if (null != shipAddress) {
						shipAddrModel.setAddress1(shipAddress.getAddress1());
						shipAddrModel.setAddress2(shipAddress.getAddress2());
						shipAddrModel.setCity(shipAddress.getCity());
						shipAddrModel.setCompany(shipAddress.getCompany());
						shipAddrModel.setCountry(shipAddress.getCountry());
						shipAddrModel.setCountry_code(shipAddress.getCountry_code());
						shipAddrModel.setFirst_name(shipAddress.getFirst_name());
						shipAddrModel.setLast_name(shipAddress.getLast_name());
						shipAddrModel.setName(shipAddress.getName());
						shipAddrModel.setLatitude(shipAddress.getLatitude());
						shipAddrModel.setLongitude(shipAddress.getLongitude());
						shipAddrModel.setPhone(shipAddress.getPhone());
						shipAddrModel.setProvince(shipAddress.getProvince());
						shipAddrModel.setProvince_code(shipAddress.getProvince_code());
						shipAddrModel.setZip(shipAddress.getZip());

					}
					orderModel.setShipping_address(shipAddrModel);

					BillAddress billAddress = order.getBilling_address();
					BillAddressModel billAddrModel = new BillAddressModel();
					if (null != billAddress) {
						billAddrModel.setAddress1(billAddress.getAddress1());
						billAddrModel.setAddress2(billAddress.getAddress2());
						billAddrModel.setCity(billAddress.getCity());
						billAddrModel.setCompany(billAddress.getCompany());
						billAddrModel.setCountry(billAddress.getCountry());
						billAddrModel.setCountry_code(billAddress.getCountry_code());
						billAddrModel.setFirst_name(billAddress.getFirst_name());
						billAddrModel.setLast_name(billAddress.getLast_name());
						billAddrModel.setName(billAddress.getName());
						billAddrModel.setLatitude(billAddress.getLatitude());
						billAddrModel.setLongitude(billAddress.getLongitude());
						billAddrModel.setPhone(billAddress.getPhone());
						billAddrModel.setProvince(billAddress.getProvince());
						billAddrModel.setProvince_code(billAddress.getProvince_code());
						billAddrModel.setZip(billAddress.getZip());

					}
					orderModel.setBilling_address(billAddrModel);

					List<ProductLineModel> prdtLinesModel = new ArrayList<ProductLineModel>();
					orderModel.setConfirmed(order.isConfirmed());
					orderModel.setCurrency(order.getCurrency());
					orderModel.setEmail(order.getEmail());
					orderModel.setId(order.getId());
					orderModel.setLocation_id(order.getLocation_id());
					orderModel.setNumber(order.getNumber());
					orderModel.setOrder_number(order.getOrder_number());
					orderModel.setPhone(order.getPhone());
					orderModel.setSource_name(order.getSource_name());
					orderModel.setSubtotal_price(order.getSubtotal_price());
					orderModel.setTaxes_included(order.isTaxes_included());
					orderModel.setTotal_discounts(order.getTotal_discounts());
					orderModel.setTotal_line_items_price(order.getTotal_line_items_price());
					orderModel.setTotal_price(order.getTotal_price());
					orderModel.setTotal_price_usd(order.getTotal_price_usd());
					orderModel.setTotal_tax(order.getTotal_tax());
					orderModel.setTotal_weight(order.getTotal_weight());
					orderModel.setUser_id(order.getUser_id());

					List<LineItem> lineItems = order.getLine_items();
					for (LineItem lineItem : lineItems) {
						ProductLineModel prdtLineModel = new ProductLineModel();
						prdtLineModel.setGift_card(lineItem.isGift_card());
						prdtLineModel.setGrams(lineItem.getGrams());
						prdtLineModel.setId(lineItem.getId());
						prdtLineModel.setName(lineItem.getName());
						prdtLineModel.setOrderModel(orderModel);
						prdtLineModel.setPrice(lineItem.getPrice());
						prdtLineModel.setProduct_exists(lineItem.isProduct_exists());
						prdtLineModel.setProduct_id(lineItem.getProduct_id());
						prdtLineModel.setQuantity(lineItem.getQuantity());
						prdtLineModel.setRequires_shipping(lineItem.isRequires_shipping());
						prdtLineModel.setSku(lineItem.getSku());
						prdtLineModel.setTaxable(lineItem.isTaxable());
						prdtLineModel.setTitle(lineItem.getTitle());
						prdtLineModel.setTotal_discount(lineItem.getTotal_discount());
						prdtLineModel.setVendor(lineItem.getVendor());

						List<TaxItem> taxItems = lineItem.getTax_lines();
						List<TaxLineModel> taxLinesModel = new ArrayList<TaxLineModel>();
						for (TaxItem taxItem : taxItems) {
							TaxLineModel taxLineModel = new TaxLineModel();
							taxLineModel.setPrice(taxItem.getPrice());
							taxLineModel.setProductLineModel(prdtLineModel);
							taxLineModel.setTitle(taxItem.getTitle());
							taxLineModel.setRate(taxItem.getRate());

							taxLinesModel.add(taxLineModel);
						}
						prdtLineModel.setTax_lines(taxLinesModel);
						prdtLinesModel.add(prdtLineModel);

					}
					orderModel.setLine_items(prdtLinesModel);
					ordersModel.add(orderModel);
				}

				orderCategoryRepository.saveAll(ordersModel);
				
				/*List<OrderModel> orderList = orderCategoryRepository.findAll();
				System.out.println("Orders --> "+orderList);*/
				sc.close();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
