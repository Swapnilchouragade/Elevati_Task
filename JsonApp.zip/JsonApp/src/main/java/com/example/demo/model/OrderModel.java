package com.example.demo.model;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "`order`")
public class OrderModel {
	@Id
	@Column(name = "order_id")
	private long id;
	private String email;
	@Column(name = "ord_number")
	private long number;
	private BigDecimal total_price;
	private BigDecimal subtotal_price;
	private long total_weight;
	private BigDecimal total_tax;
	private boolean taxes_included;
	private String currency;
	private boolean confirmed;
	private BigDecimal total_discounts;
	private BigDecimal total_line_items_price;
	private BigDecimal total_price_usd;
	private long user_id;
	private long location_id;
	private String phone;
	private long order_number;
	private String source_name;
	@OneToMany(mappedBy = "orderModel", cascade = CascadeType.ALL)
	private List<ProductLineModel> line_items;
	@Embedded
	private BillAddressModel billing_address;
	@Embedded
	private ShipAddressModel shipping_address;
	@Embedded
	private CustomerModel customer;

	public CustomerModel getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerModel customer) {
		this.customer = customer;
	}

	public BillAddressModel getBilling_address() {
		return billing_address;
	}

	public void setBilling_address(BillAddressModel billing_address) {
		this.billing_address = billing_address;
	}

	public ShipAddressModel getShipping_address() {
		return shipping_address;
	}

	public void setShipping_address(ShipAddressModel shipping_address) {
		this.shipping_address = shipping_address;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public BigDecimal getTotal_price() {
		return total_price;
	}

	public void setTotal_price(BigDecimal total_price) {
		this.total_price = total_price;
	}

	public BigDecimal getSubtotal_price() {
		return subtotal_price;
	}

	public void setSubtotal_price(BigDecimal subtotal_price) {
		this.subtotal_price = subtotal_price;
	}

	public long getTotal_weight() {
		return total_weight;
	}

	public void setTotal_weight(long total_weight) {
		this.total_weight = total_weight;
	}

	public BigDecimal getTotal_tax() {
		return total_tax;
	}

	public void setTotal_tax(BigDecimal total_tax) {
		this.total_tax = total_tax;
	}

	public boolean isTaxes_included() {
		return taxes_included;
	}

	public void setTaxes_included(boolean taxes_included) {
		this.taxes_included = taxes_included;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public boolean isConfirmed() {
		return confirmed;
	}

	public void setConfirmed(boolean confirmed) {
		this.confirmed = confirmed;
	}

	public BigDecimal getTotal_discounts() {
		return total_discounts;
	}

	public void setTotal_discounts(BigDecimal total_discounts) {
		this.total_discounts = total_discounts;
	}

	public BigDecimal getTotal_line_items_price() {
		return total_line_items_price;
	}

	public void setTotal_line_items_price(BigDecimal total_line_items_price) {
		this.total_line_items_price = total_line_items_price;
	}

	public BigDecimal getTotal_price_usd() {
		return total_price_usd;
	}

	public void setTotal_price_usd(BigDecimal total_price_usd) {
		this.total_price_usd = total_price_usd;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public long getLocation_id() {
		return location_id;
	}

	public void setLocation_id(long location_id) {
		this.location_id = location_id;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public long getOrder_number() {
		return order_number;
	}

	public void setOrder_number(long order_number) {
		this.order_number = order_number;
	}

	public String getSource_name() {
		return source_name;
	}

	public void setSource_name(String source_name) {
		this.source_name = source_name;
	}

	public List<ProductLineModel> getLine_items() {
		return line_items;
	}

	public void setLine_items(List<ProductLineModel> line_items) {
		this.line_items = line_items;
	}

}
